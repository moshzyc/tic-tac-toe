const btnAddTask = document.querySelector("#add")
const input = document.querySelector("input")

// store data somewhere

// function to add task from input

// function to render tasks

// function to remove

// function to mark as complete

// ...

const createTask = () => {
    console.log(input.value);
}

// create + add task element to list
const addTaskElement = (task) => {
    const list = document.querySelector("ol")

    // create buttons
    const btnDelete = document.createElement("button")
    btnDelete.innerText = "Delete"
    btnDelete.classList.add("btn-delete")

    const btnComplete = document.createElement("button")
    btnComplete.innerText = task.completed ? "Incomplete" : "Complete"
    btnComplete.classList.add("btn-complete")

    // create li
    const li = document.createElement("li")
    li.classList.add("task")

    // append stuff
    li.innerHTML = `<p>Task: ${task.content}</p>`
    li.append(btnComplete, btnDelete)

    // add to list
    list.append(li)
}

/*
const MY_URL = "https://jsonplaceholder.typicode.com/jjjjj"


function getDataPromise() {
    fetch(MY_URL)
        .then((res) => {
            console.log(res);
            return res.json();
        }).then((data) => {
            console.log(data);
        }).catch((err) => {
            console.error(err);
        })
}

async function getDataAsync() {
    try {
        const res = await fetch(MY_URL)
        if (!res.ok) {
            const err = new Error("Not found")
            err.code = res.status
            throw err;
        }
        const data = await res.json()
        console.log("data: ", data);
    } catch (error) {
        console.error(error)
        console.error("\nstatus: ", error.code);
    }
}

getDataAsync()
 */

// const makeMeal = (cb, isDinner) => {
//     setTimeout(() => {
//         const breakfast = '🍳'
//         const dinner = '🍔'
//         console.log("Meal is ready");

//         if (isDinner) {
//             cb(dinner)
//         }
//         else {
//             cb(breakfast)
//         }
//     }, 2000)
// }

// const makeMealPromise = (isHungry) => new Promise((resolve, reject) => {
//     setTimeout(() => {
//         const dinner = '🍔'
//         console.log("Meal is ready");
//         if (isHungry) {
//             resolve(dinner)
//         } else {
//             reject({ code: 1, message: "Not hungry" })
//         }
//     }, 2000)
// })

// const eatPromise = (dinner) => new Promise((resolve, reject) => {
//     setTimeout(() => {
//         console.log("finished eating " + dinner);
//         resol("🥑")
//     }, 1000)
// })

// async function asyncFunction() {
//     return 5;
// }

// (async () => {
//     try {
//         const avukado = await eatPromise("🍔")
//         console.log(avukado);
//         console.log(await asyncFunction());
//     } catch (error) {
//         console.error("Error: ", error);
//     }
// })()

// makeMealPromise(false)
//     .then(eatPromise)
//     .catch(err => {
//         if (!err) {
//             console.log("General error");
//         } else if (err.code == 1) {
//             console.error("Error: " + err.message)
//         }
//     })
//     .finally(() => console.log("done"))

// const eat = (cb, meal) => {
//     setTimeout(() => {
//         console.log("finished eating " + meal);
//         cb()
//     }, 1000)
// }


// const askForCheck = (cb) => {
//     setTimeout(() => {
//         console.log("Check arrived ");
//         cb()
//     }, 2000)
// }

// const payAndLeave = (cb) => {
//     setTimeout(() => {
//         console.log("leaving ");
//         cb()
//     }, 2000)
// }

// makeMeal((meal) => {
//     eat(() => {
//         askForCheck(() => {
//             payAndLeave(() => {
//                 console.log("done");
//             })
//         })
//     }, meal)
// }, false)

// const task = {
//     content: "Thing to do",
//     completed: false,
// }

// console.log(task);

/*
let globalTasks = [
    { text: "Buy groceries", completed: false },
    { text: "Do laundry", completed: true },
    { text: "Study JavaScript", completed: false }
];
*/
